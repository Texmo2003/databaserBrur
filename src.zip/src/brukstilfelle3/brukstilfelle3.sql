DELETE FROM Kunde WHERE kundeid = 69;

-- Dummy kunde
INSERT INTO Kunde (kundeID, tlfNr, navn, adresse) VALUES (69, 12345678, 'Ola Nordmann', 'Olasvei 1');